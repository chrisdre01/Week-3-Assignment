import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import {BeatLoader} from 'react-spinners';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <Suspense fallback={"Loading..."}> */}
    <Suspense fallback={<Beatloader />}>
       <App />
    </Suspense>
  </React.StrictMode>
);


