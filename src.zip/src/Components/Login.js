const [username, setUsername] = useState();
const [pass, setPass] = useState();

const navigate = useNavigate();

function loginHandler() {
    const xhr = new XMLHttpRequest();
    const url = "http://192.168.2.136/api/login.php";
    const params = 'username=${username}&pass=${pass}';
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = () => {
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            alert(xhr.responseText +" - "+ xhr.statusText)
            if (xhr.responseText == "0")
            {}
            else
            {navigate("../profile");}
        }
    }
    xhr.send(parms);

}